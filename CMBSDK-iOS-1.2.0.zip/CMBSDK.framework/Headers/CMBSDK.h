//
//  CMBSDK.h
//  CMBSDK
//
//  Created by mahuanran on 2018/6/12.
//  Copyright © 2018年 mahuanran. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CMBSDK.
FOUNDATION_EXPORT double CMBSDKVersionNumber;

//! Project version string for CMBSDK.
FOUNDATION_EXPORT const unsigned char CMBSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CMBSDK/PublicHeader.h>

#import <CMBSDK/CMBApi.h>
#import <CMBSDK/CMBApiObject.h>

